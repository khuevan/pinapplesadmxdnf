//package com.example.pinapple.adapters;
//
//import android.content.Context;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.FrameLayout;
//import android.widget.ImageView;
//import android.widget.ProgressBar;
//import android.widget.TextView;
//
//import androidx.annotation.NonNull;
//import androidx.fragment.app.Fragment;
//import androidx.recyclerview.widget.RecyclerView;
//
//import com.bumptech.glide.Glide;
//import com.bumptech.glide.RequestManager;
//import com.example.pinapple.R;
//import com.example.pinapple.models.DataVideo;
//import com.squareup.picasso.Picasso;
//
//import java.util.List;
//
//public class VideoAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
//
//    List<DataVideo.VideoModel> videoModels;
//    Context context;
//    RequestManager requestManager;
//
//
//    public VideoAdapter(List<DataVideo.VideoModel> videoModels, Context context, RequestManager requestManager) {
//        this.videoModels = videoModels;
//        this.context = context;
//        this.requestManager = requestManager;
//
//    }
//
//    @NonNull
//    @Override
//    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        return new VideoViewHolder(
//                LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item, parent, false));
//    }
//
//
//    @Override
//    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
//        Glide.with(context).load("http://10.0.2.2:8000"+videoModels.get(position).getThumbnail_image()).into((ImageView) holder.itemView);
//        ((VideoViewHolder)holder).onBind(videoModels.get(position), requestManager);
//
//    }
//
//    @Override
//    public int getItemCount() {
//        return videoModels.size();
//    }
//
//    public class VideoViewHolder extends RecyclerView.ViewHolder {
//
//        FrameLayout media_container;
//        ImageView thumbnail, volumeControl;
//        ProgressBar progressBar;
//        View parent;
//        RequestManager requestManager;
//
//        public VideoViewHolder(@NonNull View itemView) {
//            super(itemView);
//            parent = itemView;
//            media_container = itemView.findViewById(R.id.media_container);
//            thumbnail = itemView.findViewById(R.id.thumbnail);
//            progressBar = itemView.findViewById(R.id.progressBar);
//            volumeControl = itemView.findViewById(R.id.volume_control);
//        }
//
//        public void onBind(DataVideo.VideoModel videoModel, RequestManager requestManager) {
//            this.requestManager = requestManager;
//            parent.setTag(this);
//            this.requestManager
//                    .load(videoModel.getThumbnail_image())
//                    .into(thumbnail);
//        }
//    }
//}
