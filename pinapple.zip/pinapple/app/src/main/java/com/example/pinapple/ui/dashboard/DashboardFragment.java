package com.example.pinapple.ui.dashboard;

import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.request.RequestOptions;
import com.example.pinapple.R;
import com.example.pinapple.adapters.VideoPlayerRecyclerAdapter;
import com.example.pinapple.adapters.VideoPlayerRecyclerView;
import com.example.pinapple.databinding.FragmentDashboardBinding;
import com.example.pinapple.models.DataImage;
import com.example.pinapple.models.DataVideo;
import com.example.pinapple.service.ApiClient;
import com.example.pinapple.service.ApiService;
import com.example.pinapple.ui.home.HomeFragment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DashboardFragment extends Fragment {

    private DashboardViewModel dashboardViewModel;
    private FragmentDashboardBinding binding;
    
    private VideoPlayerRecyclerView mRecyclerView;
//    ArrayList<DataVideo.VideoModel> mediaObjects;
    List<DataVideo.VideoModel> mediaObjects = new ArrayList<>();
    DataVideo dataVideo;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        dashboardViewModel =
                new ViewModelProvider(this).get(DashboardViewModel.class);

        binding = FragmentDashboardBinding.inflate(inflater, container, false);
        View root = binding.getRoot();


        mRecyclerView = root.findViewById(R.id.video_recyclerView);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        mRecyclerView.setLayoutManager(layoutManager);
        initRecyclerView();
        VideoPlayerRecyclerAdapter adapter = new VideoPlayerRecyclerAdapter((ArrayList<DataVideo.VideoModel>) mediaObjects, initGlide());

        mRecyclerView.setAdapter(adapter);
        return root;
    }

    private void  initRecyclerView(){
        ApiService.getService().getDataVideos().enqueue(new Callback<DataVideo>() {

            @Override
            public void onResponse(Call<DataVideo> call, Response<DataVideo> response) {
                if (response.isSuccessful() && response.body() != null) {
                    dataVideo = response.body();
                    mediaObjects.addAll(dataVideo.getData());
                    mRecyclerView.setMediaObjects((ArrayList<DataVideo.VideoModel>) mediaObjects);
                }

            }

            @Override
            public void onFailure(Call<DataVideo> call, Throwable t) {

            }
        });
    }

    private RequestManager initGlide(){
        RequestOptions options = new RequestOptions()
                .placeholder(R.color.white)
                .error(R.color.white);

        return Glide.with(this)
                .setDefaultRequestOptions(options);
    };

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        if(mRecyclerView!=null)
            mRecyclerView.releasePlayer();
        super.onDestroy();
    }
}